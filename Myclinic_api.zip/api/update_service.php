<?php

require('config.php');

   $title=$_POST['title'];
   $subTitle=$_POST['subTitle'];
   $imageUrl=$_POST['imageUrl'];
   $id=$_POST['id'];
   $description=$_POST['description'];
   $updatedTimeStamp = date("Y-m-d H:i:s"); 
  

  $sql= "UPDATE `service` SET
  `updatedTimeStamp` = '$updatedTimeStamp',
  `title` = '$title',
   `subTitle` = '$subTitle',
   `description`='$description',
  `imageUrl` = '$imageUrl'
 
  WHERE `service`.`id` = $id";

  $update = mysqli_query($conn,$sql);
            
 
    if($update){
               
                echo "success";
    }
    else{
        echo "error";
        
    }
    $conn->close();
    return;

?>