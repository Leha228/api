<?php

require('config.php');


  $firstName=$_POST['firstName'];
  $lastName=$_POST['lastName'];
  $email=$_POST['email'];
  $pNo1=$_POST['pNo1'];
  $pNo2=$_POST['pNo2'];
  $description=$_POST['description'];
  $whatsAppNo=$_POST['whatsAppNo'];
  $subTitle=$_POST['subTitle'];
  $profileImageUrl=$_POST['profileImageUrl'];
  $address=$_POST['address'];
  $aboutUs=$_POST['aboutUs'];
  $id=$_POST['id'];


   $updatedTimeStamp = date("Y-m-d H:i:s"); 
  
$sql = "UPDATE `drprofile` SET 

  `firstName`='$firstName',
  `lastName`='$lastName',
  `email`='$email',
  `pNo1`='$pNo1',
  `pNo2`='$pNo2',
  `description`='$description',
  `whatsAppNo`='$whatsAppNo',
  `subTitle`='$subTitle',
  `profileImageUrl`='$profileImageUrl',
  `address`='$address',
  `aboutUs`='$aboutUs',
  `updatedTimeStamp` ='$updatedTimeStamp'
WHERE `drprofile`.`id` = '$id'";

  $update = mysqli_query($conn, $sql );
            
 
    if($update){
               
                echo "success";
    }
    else{
        echo "error";
        
    }
    $conn->close();
    return;

?>