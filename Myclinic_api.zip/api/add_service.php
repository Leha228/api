<?php

require('config.php');

   $title=$_POST['title'];
   $subTitle=$_POST['subTitle'];
   $imageUrl=$_POST['imageUrl'];
   $description=$_POST['description'];
   
 
   $createdTimeStamp = date("Y-m-d H:i:s");  
   $updatedTimeStamp = date("Y-m-d H:i:s"); 
  

  

  $insert = mysqli_query($conn,
  "INSERT INTO `service`(
   title,
    subTitle,
      imageUrl,
      description,
 
    createdTimeStamp,
    updatedTimeStamp
      )
      VALUES(

   '$title',
   '$subTitle',
   '$imageUrl',
    '$description',
   '$createdTimeStamp',
   '$updatedTimeStamp'
      
      )"
            );
            
 
    if($insert){
               
                echo "success";
    }
    else{
        echo "error";
        
    }
    $conn->close();
    return;

?>