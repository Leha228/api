<?php

require('config.php');

  $appointmentDate=$_POST['appointmentDate'];
  $appointmentStatus=$_POST['appointmentStatus'];
  $appointmentTime=$_POST['appointmentTime'];
  $pCity=$_POST['pCity'];
  $age=$_POST['age'];
  $pEmail=$_POST['pEmail'];
  $pFirstName=$_POST['pFirstName'];
  $pLastName=$_POST['pLastName'];
  $serviceName=$_POST['serviceName'];
  $serviceTimeMin=$_POST['serviceTimeMin'];
  $uId=$_POST['uId'];
  $pPhn=$_POST['pPhn'];
  $description=$_POST['description'];
  $searchByName=$_POST['searchByName'];
  $uName=$_POST['uName'];
  $gender=$_POST['gender'];

  $createdTimeStamp = date("Y-m-d H:i:s");  
  $updatedTimeStamp = date("Y-m-d H:i:s"); 
  
  $insert = mysqli_query($conn,
  "INSERT INTO `appointments`(
      appointmentDate,
      appointmentStatus,
      appointmentTime,
      pCity,
      age,
      pEmail,
      pFirstName,
      pLastName,
      serviceName,
      serviceTimeMin,
      uId,
      pPhn,
      description,
      searchByName,
      uName,
      gender,
      createdTimeStamp,
      updatedTimeStamp
      )
      VALUES(

 '$appointmentDate',
 '$appointmentStatus',
 '$appointmentTime',
 '$pCity',
  '$age',
  '$pEmail',
  '$pFirstName',
  '$pLastName',
  '$serviceName',
  '$serviceTimeMin',
  '$uId',
  '$pPhn',
  '$description',
  '$searchByName',
  '$uName',
  '$gender',
  '$createdTimeStamp',
   '$updatedTimeStamp'
      
      )"
            );
            
      $last_id = mysqli_insert_id($conn);
 
    if($insert){
               
                echo "$last_id";
    }
    else{
        echo "error";
        
    }
    $conn->close();
    return;

?>