<?php

$servername="localhost";
$username=";
$password="";
$dbname="";

//create connection 
$conn=new mysqli($servername, $username,   $password,$dbname);
//check connection
if($conn->connect_error){
    die("Connection Faild: " . $conn->connect_error);
    return;
}

?>