<?php

require('config.php');

  
  $firstName=$_POST['firstName'];
  $lastName=$_POST['lastName'];
  $city=$_POST['city'];
  $email=$_POST['email'];
  $imageUrl=$_POST['imageUrl'];
  $searchByName=$_POST['searchByName'];
  $age=$_POST['age'];
  $uId=$_POST['uId'];
    $gender=$_POST['gender'];

  $updatedTimeStamp = date("Y-m-d H:i:s"); 
  
  
   $sql="UPDATE `userList` SET
  `firstName`='$firstName',
  `lastName`='$lastName',
  `city`='$city',
  `email`='$email',
  `imageUrl`='$imageUrl',
  `searchByName`='$searchByName',
  `age`='$age',
  `gender`='$gender',
  `updatedTimeStamp`='$updatedTimeStamp'
 
   WHERE `userList`.`uId` = '$uId'";
  

  $update = mysqli_query($conn,$sql );
            

 
    if($update){
               
                echo "success";
    }
    else{
        echo "error";
        
    }
    $conn->close();
    return;

?>