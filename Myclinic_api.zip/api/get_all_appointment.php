<?php

require('config.php');

 $status=$_GET["status"];
  $type=$_GET["type"];
  $firstDate=$_GET["firstDate"];
  $lastDate=$_GET["lastDate"];
    $limit=$_GET["limit"];
  
 $array=array_map('strval', explode(',', $status));
 $array = implode("','",$array);
 
 $array2=array_map('strval', explode(',', $type));
 $array2 = implode("','",$array2);

if($firstDate=="All"&&$lastDate=="All" ){
      $result=mysqli_query($conn,"select * from appointments where  `appointmentStatus` IN ('".$array."') AND `serviceName` IN ('".$array2."') ORDER BY updatedTimeStamp DESC LIMIT $limit");
}
else{
      $result=mysqli_query($conn,"select * from appointments where  `appointmentStatus` IN ('".$array."') AND `serviceName` IN ('".$array2."') AND `appointmentDate` >='$firstDate' AND appointmentDate <= '$lastDate' ORDER BY updatedTimeStamp DESC LIMIT $limit");
}


$data=array();
while($row=$result->fetch_assoc()){

    $data[]=$row;

}

echo json_encode($data);

$conn->close();
return;
?>